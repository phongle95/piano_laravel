<?php /* C:\xampp\htdocs\piano_laravel\resources\views/PageAdmin1/khachhang/them.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>

<div class="row">

    <div class="col-md-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        <!-- DATA TABLE -->
            <div class="card">
                    <div class="card-header">
                        <strong>Thêm Khách Hàng</strong>

                    </div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(route('PageAdmin1.khachhang.them')); ?>"  enctype="multipart/form-data" method="POST" class="form-horizontal">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Tên Khách Hàng</label><br>
                                                    <input type="text" id="text-input" name="tenKH" value="<?php echo e(old('tenKH')); ?>" placeholder="Nhập tên khách hàng" class="form-control">
                                                </div>

                                    </div>



                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Chọn Hình</label><br><br>
                                                    <input type="file" style="width:200px" name="img" value="<?php echo e(old('img')); ?>">
                                            </div>

                                    </div>
                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Địa Chỉ</label><br>
                                                    <input type="text" id="text-input" placeholder="Nhập địa chỉ" name="diaChi" value="<?php echo e(old('diaChi')); ?>" class="form-control">
                                                </div>

                                    </div>

                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Đánh Giá</label><br>
                                                    <textarea  id="textarea-input" rows="5" placeholder="Nhập nội dung" class="form-control" name="danhGia"><?php echo e(old('danhGia')); ?></textarea>
                                                </div>

                                    </div>




                               <div class="card-footer">
                                    <button type="submit" class="btn btn-success btn-fw">
                                       Thêm
                                    </button>
                                    <a href="<?php echo e(route('PageAdmin1.khachhang.danhsach')); ?>"  class="btn btn-info btn-fw"> Quay về
                                    </a>
                                </div>
                        </form>
                    </div>

                </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin2.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>