<?php /* C:\xampp\htdocs\piano_laravel\resources\views/PageAdmin/loaisanpham/them.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-2"></div>
         <div class="col-md-8">
            <div class="card">
               <div class="card-header card-header-primary">
                  <h4 style="text-align:center;font-weight: 600" class="card-title">Thêm loại sản phẩm</h4>
               </div>
               <div class="card-body">
                    

                    <?php if(session('thongbao')): ?>
                    <div style="color:red;font-weight: 400">
                      <?php echo e(session('thongbao')); ?>

                    </div>

                   <?php endif; ?>
                  <form action="<?php echo e(route('PageAdmin.loaisanpham.them')); ?>" method="POST">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                     <br>
                     <div class="row">
                        <div class="col-md-4">
                        </div>
                        <div class="col-md-4">
                           <div class="form-group">
                              <label class="bmd-label-floating">Tên sản phẩm</label>
                              <input type="text" class="form-control" name="tenSP">
                           </div>
                        </div>
                        <div class="col-md-4">
                        </div>
                     </div>
                     <button type="submit" class="btn btn-primary pull-right">Thêm loại sản phẩm</button>
                     <div class="clearfix"></div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>