<?php /* C:\xampp\htdocs\piano_laravel\resources\views/PageAdmin/sanpham/sua.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-9">
            <div class="card">
               <div class="card-header card-header-primary">
                  <h4 style="text-align:center;font-weight: 600" class="card-title">Sửa sản phẩm</h4>


               </div>
               <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
               <div class="card-body">
                  <form action="<?php echo e(route('PageAdmin.sanpham.sua',$sanpham->id)); ?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                        <div class="row">
                                <div class="col-md-12">
                                   <div class="form-group">
                                      <label class="bmd-label-floating" style="color:black;font-weight: 600">Tên Sản Phẩm</label>
                                      <input type="text" class="form-control" name="tenSP" value="<?php echo e($sanpham->tenSP); ?>">
                                   </div>
                                </div>
                             </div>
                             <div class="row">
                                    <div class="col-md-12">
                                       <div class="form-group">
                                          <label class="bmd-label-floating" style="color:black;font-weight: 600">Giá Sản Phẩm</label>
                                          <input type="number" class="form-control" name="gia"value="<?php echo e($sanpham->gia); ?>">
                                       </div>
                                    </div>
                                 </div>
                                  <div class="row">
                                    <div class="col-md-12">
                                        <label class="bmd-label-floating" style="color:black;font-weight: 600">Chọn hình</label>
                                        <img src="/upload/<?php echo e($sanpham->img); ?>" width="200px" height="150px" alt="salme">
                                         <input type="file" style="width:200px" name="img" >
                                    </div>
                                 </div>
                               <br>

                     <div class="row">
                        <div class="col-md-12">
                           <div class="form-group">
                              <div class="form-group">
                                 <label class="bmd-label-floating" style="color:black;font-weight: 600">Tóm tắt sản phẩm</label>
                                 <textarea class="form-control" rows="5" name="tomTat"><?php echo e($sanpham->tomTat); ?></textarea>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                            <div class="form-group col-md-12">
                                    <label style="color:black;font-weight: 600">Mô tả sản phẩm</label><br>
                                    <textarea name="MTSP" class="form-control "id="editor1"><?php echo e($sanpham->MTSP); ?></textarea>
                           </div>
                      </div>
                      <div class="row">
                            <div class="form-group col-md-12">
                                    <label style="color:black;font-weight: 600">Thông số kĩ thuật</label><br>
                                    <textarea name="TSKT" class="form-control" id="editor2"><?php echo e($sanpham->TSKT); ?></textarea>
                           </div>
                      </div>




                     <div class="row">
                            <div class="col-md-12">
                               <div class="form-group">
                                  <label class="bmd-label-floating" style="color:black;font-weight: 600">Mã Sản Phẩm</label>

                                  <select class="custom-select" style="width:200px;" name="maSP" >
                                     <?php $__currentLoopData = $loaisanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lsp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option  <?php if($sanpham->maSP == $lsp->maSP): ?> <?php echo e("selected"); ?> <?php endif; ?> value="<?php echo e($lsp->maSP); ?>"><?php echo e($lsp->tenSP); ?></option>

                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                               </div>
                            </div>
                         </div>
                     <button type="submit" class="btn btn-primary pull-right">Sửa Sản Phẩm</button>
                     <div class="clearfix"></div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>