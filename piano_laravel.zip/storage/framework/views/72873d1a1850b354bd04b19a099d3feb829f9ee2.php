<?php /* C:\xampp\htdocs\piano_laravel\resources\views/PageAdmin1/loaitin/them.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="row">
   <div class="col-md-12">
      <!-- DATA TABLE -->
      <div class="card">
         <div class="card-header">
            <strong>Thêm Loại Tin</strong>
         </div>
         <div class="card-body card-block">
            <form action="<?php echo e(route('PageAdmin1.loaitin.them')); ?>" method="POST" class="form-horizontal">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
               <div class="row form-group">
                  <div class="col-12 col-md-12">
                     <label class="badge badge-info">Tên Loại Tin </label><br>
                     <input type="text" id="text-input" name="tenLoaiTin" value="<?php echo e(old('tenLoaiTin')); ?>" placeholder="Nhập tên loại tin" class="form-control">
                  </div>
               </div>
               <div class="card-footer">
                  <button type="submit" class="btn btn-success btn-fw">
                  Thêm
                  </button>
                  <a href="<?php echo e(route('PageAdmin1.loaitin.danhsach')); ?>" class="btn btn-info btn-fw">
                  Quay về
                  </a>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin2.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>