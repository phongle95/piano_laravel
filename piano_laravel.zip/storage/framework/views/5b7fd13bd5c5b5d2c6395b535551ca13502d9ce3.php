<?php /* C:\xampp\htdocs\piano_laravel\resources\views/PageAdmin/menu/sua.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-9">
            <div class="card">
               <div class="card-header card-header-primary">
                  <h4 style="text-align:center;font-weight: 600" class="card-title">Sửa Menu</h4>


               </div>
               
               <div class="card-body">
                  <form action="<?php echo e(route('PageAdmin.menu.sua',$menu->id)); ?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

                        <div class="row">
                            <div class="col-md-12">
                               <div class="form-group">
                                  <label class="bmd-label-floating" style="color:black;font-weight: 600">Tên Menu</label>
                                  <input type="text" class="form-control" name="tenMenu" value="<?php echo e($menu->tenMenu); ?>">
                               </div>
                            </div>
                         </div>

                <br>

                     <div class="row">
                            <div class="form-group col-md-12">
                                    <label style="color:black;font-weight: 600;padding-left:20px">Nội Dung</label><br>
                                    <textarea name="noiDung" class="form-control "id="editor3"><?php echo e($menu->noiDung); ?></textarea>
                           </div>
                      </div>




                     <button type="submit" class="btn btn-primary pull-right">Sửa</button>
                     <div class="clearfix"></div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>