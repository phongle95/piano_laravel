<?php /* C:\xampp\htdocs\piano_laravel\resources\views/PageAdmin/trangchu.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<br><br><br><br><br>

<h2 style="text-align:center;font-weight: 600;">Hello Admin mời chọn menu bên trái</h2>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>