<?php /* C:\xampp\htdocs\piano_laravel\resources\views/Layouts/facebook.blade.php */ ?>
<h2> <span class="badge badge-primary">Fanpage Facebook</span></h2>
<br>
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fpianonhapkhaudanang&tabs=timeline&width=340&height=600&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="600" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
<br><br>
<h2> <span class="badge badge-primary">Top Sản Phẩm Bán Chạy </span></h2>




<div class="featured-section">
        <div class="container">
           <h2 class="carousel-title">Đàn Piano HOT</h2>
           <div class="featured-products owl-carousel owl-theme owl-dots-top">

              


              <div class="product">
                    <div class="row">
                            <div class="col">
                                <img src="assets/images/products/small/product-6.jpg" alt="product">
                            </div>
                            <div class="col">
                                tieu de
                            </div>

                        </div>
               </div>
               <!-- End .product -->

              
           </div>
           <!-- End .featured-proucts -->
        </div>
        <!-- End .container -->
     </div>
     <!-- End .featured-section -->
