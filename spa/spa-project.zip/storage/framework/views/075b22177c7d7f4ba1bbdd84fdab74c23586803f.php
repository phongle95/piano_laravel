
<!--close-top-serch-->
<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="<?php echo e(request()->is('admin') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.index.index')); ?>"><i class="icon icon-home"></i> <span>Trang chủ</span></a> </li>
    <li class="<?php echo e(request()->is('admin/cat*') ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.category.index')); ?>"><i class="icon icon-signal"></i> <span>Quản lý danh mục</span></a> </li>
    <li class="<?php echo e(request()->is('admin/news*') ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.news.index')); ?>"><i class="icon icon-inbox"></i> <span>Quản lý tin tức</span></a> </li>
    <li class="<?php echo e(request()->is('admin/package*') ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.catpackage.index')); ?>"><i class="icon icon-inbox"></i> <span>Quản lý danh mục dịch vụ</span></a></li>
    <li class="<?php echo e(request()->is('admin/service*') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.service.index')); ?>"><i class="icon icon-th"></i> <span>Quản lý dịch vụ</span></a></li>
    <li class="<?php echo e(request()->is('admin/user*') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.user.index')); ?>"><i class="icon icon-user"></i> <span>Quản lý admin</span></a></li>
    <li class="<?php echo e(request()->is('admin/contact*') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.contact.index')); ?>"><i class="icon icon-fullscreen"></i> <span>Quản lý liên hệ</span></a></li>
  </ul>
</div>
<!--sidebar-menu-->