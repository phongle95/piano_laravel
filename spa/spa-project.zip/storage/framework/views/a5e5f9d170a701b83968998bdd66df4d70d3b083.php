<?php $__env->startSection('content'); ?>
<div role="main" class="main" style="background-color: #eee">

				<div class="slider-container rev_slider_wrapper">
					<div id="revolutionSlider" class="slider rev_slider" data-version="5.4.8" data-plugin-revolution-slider data-plugin-options="{'delay': 4000, 'gridwidth': 1170, 'gridheight': 400, 'disableProgressBar': 'on', 'responsiveLevels': [4096,1200,992,500], 'parallax': { 'type': 'scroll', 'origo': 'enterpoint', 'speed': 1000, 'levels': [2,3,4,5,6,7,8,9,12,50], 'disable_onmobile': 'on' }, 'navigation' : {'arrows': { 'enable': false }, 'bullets': {'false': true, 'style': 'bullets-style-1', 'h_align': 'center', 'v_align': 'bottom', 'space': 7, 'v_offset': 70, 'h_offset': 0}}}">
						<ul>
							<li>
								<img src="/templates/spa/img/banner-thammun.png"
													alt=""
													data-bgposition="center center" 
													data-bgfit="cover" 
													data-bgrepeat="no-repeat" 
													class="img-fluid"
													style="min-height: 110px;">
							</li>
						</ul>
					</div>
				</div>

				<!-- Intro -->
				<div class="home-intro home-intro-quaternary" style="background-color:#333;margin:0;" id="home-intro">
					<div class="container">

						<div class="row text-center">
							<div class="col">
								<p class="mb-0">
									Các bạn sẽ tìm thấy những dịch vụ spa và thẩm mỹ tốt nhất tại <span class="highlighted-word highlighted-word-animation-1 highlighted-word-animation-1-light text-color-light font-weight-semibold text-5">DanaSpa</span>
									<span>Với đội ngũ bác sỹ tư vấn chuyên nghiệp và nhiều kinh nghiệm</span>
								</p>
							</div>
						</div>

					</div>
				</div>
				<!-- End Intro -->

				<!-- Start Service -->
				<div class="container py-4" style="background-color: #fff; margin-top:40px;">

					<div class="row">
						<div class="col-lg-12">
							<div class="blog-posts single-post">
							
								<article class="post post-large blog-single-post border-0 m-0 p-0">
									<div class="post-date ml-0">
										<span class="day">10</span>
										<span class="month">Jan</span>
									</div>
							
									<div class="post-content ml-0">
							
										<h1 class="font-weight-bold text-color-primary"><a>KHÓA HỌC SPA - ĐÀO TẠO CHĂM SÓC DA CHUYÊN NGHIỆP</a></h1>

										<p></p>
							

										<strong><p>Bạn đang cần tìm khóa học nghề spa chuyên nghiệp, nhưng chưa tìm được nơi uy tín để học tập và thực hành. Bạn mong muốn sau khi học mình được có kinh nghiệm thực tế, được làm việc ngay. Công việc ổn định và thu nhập cao hàng tháng. Với khóa học nghề spa chuyên nghiệp tại DaNa, bạn sẽ đảm bảo về kiến thức vững và tay nghề tốt, để có thể làm việc tại các spa uy tín thu nhập cao.</p></strong>

										<h3 class="font-weight-bold text-color-primary">VÌ SAO NÊN HỌC NGHỀ TẠI DANA</h3>

										<p>
											<ul>
												<li>Giáo trình đào tạo chăm sóc da chuyên nghiệp dựa trên chương trình đào tạo Chăm sóc da tại Hàn Quốc, DaNa đã kế thừa, chọn lọc và đúc kết phương pháp dạy và học phù hợp nhất cho người Việt. DaNa tự hào là cơ sở đào tạo nghề spa chuyên nghiệp, uy tín và chất lượng, sự lựa chọn hàng đầu cho những bạn chưa biết gì về nghề spa, đam mê nghề thẩm mỹ và đang phân vân trong việc xác định học nghề spa ở đâu tại Đà Nẵng.</li>
												<li>Giảng viên phụ trách lớp: Có kinh nghiệm nhiều năm trong đào tạo chăm sóc da, dạy nghề spa, tốt nghiệp từ chuyên ngành Thẩm mỹ của Hàn và Đại Học Y Dược.</li>
												<li>Thực hành trên người thật, học viên không phải trả chi phí thuê mẫu trong suốt quá trình học nghề spa tại trung tâm.</li>
												<li>Học nghề spa với lý thuyết song song thực hành, đi sát với thực tế, thời gian thực hành >80%.</li>
												<li>Trang thiết bị, máy móc đào tạo nghề spa trường hỗ trợ.</li>
												<li>Không bán mỹ phẩm, giới thiệu các sản phẩm uy tín, hợp túi tiền của người học.</li>
												<li>Hỗ trợ giới thiệu việc làm ngay tại các spa sau khi tốt nghiệp với mức thu nhập ổn định.</li>
											</ul>
										</p>
										<img src="/templates/spa/img/learn-1.png"
											alt=""
											class="img-fluid"
											style="max-height:500px;margin: 0 auto; display: block;">

										<h3 class="font-weight-bold text-color-primary">NỘI DUNG KHÓA HỌC NGHỀ SPA CHUYÊN NGHIỆP</h3>

										

										<h4 class="text-color-primary">CHUYÊN MỤC: CHĂM SÓC DA MẶT + BODY CHUYÊN SÂU</h4>
										<p>
											<ul>
												<li>Chăm sóc da từ cơ bản đến nâng cao.</li>
												<li>Công nghệ laser điều trị nám, tàn nhang tận gốc không để lại sẹo, không đau, không tổn thương da.</li>
												<li>Công nghệ oxyjet điều trị se khít nang lông - trắng sáng da, cung cấp Oxy tươi cho da.</li>
												<li>Học nghề spa với lý thuyết song song thực hành, đi sát với thực tế, thời gian thực hành >80%.</li>
												<li>Công nghệ triệt lông vĩnh viễn triệt tiêu tận gốc.</li>
												<li>Máy giảm béo kết hợp giữa kỹ thuật chuyên sâu và công nghệ hiện đại đánh tan mỡ.</li>
												<li>Tắm trắng phi thuyền.</li>
												<li>Máy phi kim tế bào gốc: trị sẹo mụn, thâm mụn, trắng sáng da, tái tạo và trẻ hóa da.</li>
											</ul>
										</p>
										<h3 class="font-weight-bold text-color-primary">NỘI DUNG KHÓA HỌC NGHỀ SPA CHUYÊN NGHIỆP</h3>
										<img src="/templates/spa/img/learn-2.png"
											alt=""
											class="img-fluid"
											style="max-height:500px;margin: 0 auto; display: block;">
										<p dir="ltr">——————————————–</p>
										<p dir="ltr">TRUNG TÂM THẨM MỸ CÔNG NGHỆ CAO</p>
										<p dir="ltr">DANA BEAUTY CLINIC &amp; ACADEMY</p>
										<p dir="ltr">Địa chỉ: 455 Trần Hưng Đạo – TP. Đà Nẵng</p>
										<p dir="ltr">Hotline: 0934 734 555</p>
									</div>
								</article>			
							</div>
						</div>
					</div>

				</div>

			</div>
				<!-- End service -->

			</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
<title>Dana Spa - Thẩm mỹ viện, SPA và chăm sóc da Uy tín nhất tại Đà Nẵng</title>
		<meta name="keywords" content="spa da nang, tham my vien da nang, da nang spa, cham soc da, giam mo bung" />
		<meta name="description" content='Thẩm mỹ viện, SPA và chăm sóc da Uy tín nhất tại Đà Nẵng, sử dụng công nghệ nước ngoài và được phục vụ bởi các bác sĩ nước ngoài ' />
		<meta name="news_keywords" content="Thẩm mỹ viện, SPA và chăm sóc da Uy tín nhất tại Đà Nẵng, sử dụng công nghệ nước ngoài và được phục vụ bởi các bác sĩ nước ngoài ">

		<meta property="og:title" content="Thẩm mỹ viện, SPA và chăm sóc da Uy tín nhất tại Đà Nẵng" />
		<meta property="og:description" content="Thẩm mỹ viện, SPA và chăm sóc da Uy tín nhất tại Đà Nẵng sử dụng mỹ phẩm cao cấp trên thế giới" />
		<meta property="og:image" content= "/templates/spa/img/logo.png" />
		<meta property="og:url" itemprop="url" content="<?php echo e(route('spa.service.learnskin')); ?>">

		<meta itemprop="name" content="Dana Spa - Thẩm mỹ viện, SPA và chăm sóc da Uy tín nhất tại Đà Nẵng" />
		<meta itemprop="description" content="Thẩm mỹ viện, SPA và chăm sóc da Uy tín nhất tại Đà Nẵng, sử dụng công nghệ nước ngoài và được phục vụ bởi các bác sĩ nước ngoài" />
		<meta itemprop="image" content= "/templates/spa/img/logo.png" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.spa.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>