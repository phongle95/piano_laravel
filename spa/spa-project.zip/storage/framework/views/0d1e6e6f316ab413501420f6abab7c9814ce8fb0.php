<!DOCTYPE html>
<html lang="en">
<head>
<title>Matrix Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="/templates/css/bootstrap.min.css" />
<link rel="stylesheet" href="/templates/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="/templates/css/fullcalendar.css" />
<link rel="stylesheet" href="/templates/css/matrix-style.css" />
<link rel="stylesheet" href="/templates/css/matrix-media.css" />
<link href="font-awesome//templates/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="/templates/css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">Spa Admin</a></h1>
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  
</div>
<!--close-top-Header-menu-->
<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>