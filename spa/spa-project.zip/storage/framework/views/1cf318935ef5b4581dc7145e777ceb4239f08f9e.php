
<!--close-top-serch-->
<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="<?php echo e(route('admin.index.index')); ?>"><i class="icon icon-home"></i> <span>Trang chủ</span></a> </li>
    <li> <a href="charts.html"><i class="icon icon-signal"></i> <span>Quản lý danh mục</span></a> </li>
    <li> <a href="widgets.html"><i class="icon icon-inbox"></i> <span>Quản lý tin tức</span></a> </li>
    <li><a href="tables.html"><i class="icon icon-th"></i> <span>Quản lý Story</span></a></li>
    <li><a href="grid.html"><i class="icon icon-fullscreen"></i> <span>Quản lý lịch hẹn</span></a></li>
    <li><a href="grid.html"><i class="icon icon-fullscreen"></i> <span>Quản lý admin</span></a></li>
    <li><a href="grid.html"><i class="icon icon-fullscreen"></i> <span>Quản lý liên hệ</span></a></li>
    <li><a href="grid.html"><i class="icon icon-fullscreen"></i> <span>Quản lý feedback</span></a></li>
  </ul>
</div>
<!--sidebar-menu-->