@include('templates.admin.header')
@include('templates.admin.leftbar')
	@yield('content')
@include('templates.admin.footer')