@include('templates.spa.header')
	@yield('content')
@include('templates.spa.footer')