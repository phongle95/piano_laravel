<?php /* C:\xampp\htdocs\piano_salem_laravel\resources\views/Pages/timkiem.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<!-- End .header -->


<main class="main">
        <img src="https://vietthuong.vn//upload/images/anh-cover-piano-upright.jpg" alt="salem piano">
        <nav aria-label="breadcrumb" class="breadcrumb-nav">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Kết Quả : <?php echo e($tukhoa); ?></li>
                </ol>
            </div><!-- End .container -->
        </nav>

        <div class="container">
            <div class="row">


                <div class="col-lg-8">
                    <?php $__currentLoopData = $ketqua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="row">
                            <div class="col-lg-5">
                                <figure class="product-image-container">
                                    <a href="<?php echo e(route('Pages.chitiet',['slug' => str_slug($kq->tenSP),'id'=>$kq->id])); ?>" class="product-image">
                                    <img src="/upload/<?php echo e($kq->img); ?>" alt="product">
                                    </a>
                                </figure>
                            </div>

                            <div class="col-lg-7">
                                   <a href="<?php echo e(route('Pages.chitiet',['slug' => str_slug($kq->tenSP),'id'=>$kq->id])); ?>"> <h3 style="text-align:center;font-weight: 600;"><?php echo e($kq->tenSP); ?></h3></a>
                                    <p  style="text-align:center;font-weight: 600;">Giá : <span style="color:red"><?php echo e(number_format($kq->gia)); ?></span> đ </p>

                                    <p  style="text-align:center;font-weight: 600;"><?php echo e($kq->tomTat); ?></p>
                            </div>

                       </div>
                       <hr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div><!-- End .col-lg-8 -->

                <div class="col-lg-4">
                        <h2> <span class="badge badge-primary">Fanpage Facebook</span></h2>
                        <br>
                        <iframe
                           src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fpianonhapkhaudanang&tabs=timeline&width=340&height=600&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId"
                           width="340" height="600" style="border:none;overflow:hidden" scrolling="no" frameborder="0"
                           allowTransparency="true" allow="encrypted-media"></iframe>
                </div><!-- End .col-lg-4 -->
            </div><!-- End .row -->
        </div><!-- End .container -->

        <div class="mb-6"></div><!-- margin -->
    </main><!-- End .main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>