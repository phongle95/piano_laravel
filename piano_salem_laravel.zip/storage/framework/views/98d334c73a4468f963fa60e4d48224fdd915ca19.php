<?php /* C:\xampp\htdocs\piano_salem_laravel\resources\views/PageAdmin/sanpham.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<br>
<h2 style="text-align:center;font-weight: 600;">Danh sách sản phẩm</h2>
<!-- End Navbar -->
<div class="content">
<div class="container-fluid">
<div class="row">
   <div class="col-md-12">
      <div class="card">
         <div class="card-header card-header-primary">
            <h4 class="card-title ">SẢN PHẨM</h4>
         </div>
         <div class="card-body">
            <div class="table-responsive">
               <table class="table">
                  <thead>
                     <th style="text-align:left;font-weight: 600;">
                        TÊN SẢN PHẨM
                     </th>
                     <th style="text-align:left;font-weight: 600;">
                        GIÁ SẢN PHẨM
                     </th>
                     <th style="text-align:left;font-weight: 600;">
                        HÌNH SẢN PHẨM<Map></Map>
                     </th>
                     <th style="text-align:left;font-weight: 600;">
                        SỬA
                     </th>
                     <th style="text-align:left;font-weight: 600;">
                        XÓA
                     </th>
                  </thead>
                  <a href="them-san-pham" style="margin-left:85%" class="btn btn-primary btn-round">Thêm sản phẩm</a>
                  <tbody>
                     <tr>
                        <td style="text-align:left;font-weight: 500;">
                           YAMAHA
                        </td>
                        <td style="text-align:left;font-weight: 500;">
                           50.000.000
                        </td>
                        <td style="text-align:left;font-weight: 500;">
                           HÌNH 1
                        </td>
                        <td style="text-align:left;font-weight: 500;">
                           <a href="#pablo" class="btn btn-primary btn-round">Sửa</a>
                        </td>
                        <td style="text-align:left;font-weight: 500;">
                           <a href="#pablo" class="btn btn-primary btn-round">Xóa</a>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>