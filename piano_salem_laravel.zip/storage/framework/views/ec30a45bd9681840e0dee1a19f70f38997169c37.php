<?php /* C:\xampp\htdocs\piano_salem_laravel\resources\views/PageAdmin/themsanpham.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-9">
            <div class="card">
               <div class="card-header card-header-primary">
                  <h4 style="text-align:center;font-weight: 600" class="card-title">Thêm sản phẩm</h4>
               </div>
               <div class="card-body">
                  <form>

                        <div class="row">
                                <div class="col-md-12">
                                   <div class="form-group">
                                      <label class="bmd-label-floating" style="color:black;font-weight: 600">Tên Sản Phẩm</label>
                                      <input type="text" class="form-control">
                                   </div>
                                </div>
                             </div>
                             <div class="row">
                                    <div class="col-md-12">
                                       <div class="form-group">
                                          <label class="bmd-label-floating" style="color:black;font-weight: 600">Giá Sản Phẩm</label>
                                          <input type="number" class="form-control">
                                       </div>
                                    </div>
                                 </div>
                                  <div class="row">
                                    <div class="col-md-12">
                                        <label class="bmd-label-floating" style="color:black;font-weight: 600">Chọn hình</label>
                                 <input type="file" style="width:200px">
                                    </div>
                                 </div>
                               <br>

                     <div class="row">
                        <div class="col-md-12">
                           <div class="form-group">
                              <div class="form-group">
                                 <label class="bmd-label-floating" style="color:black;font-weight: 600">Tóm tắt sản phẩm</label>
                                 <textarea class="form-control" rows="5"></textarea>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                            <div class="form-group col-md-12">
                                    <label style="color:black;font-weight: 600">Mô tả sản phẩm</label><br>
                                    <textarea name="txtContent" class="form-control "id="editor1" ></textarea>
                           </div>
                      </div>
                      <div class="row">
                            <div class="form-group col-md-12">
                                    <label style="color:black;font-weight: 600">Thông số kĩ thuật</label><br>
                                    <textarea name="txtContent" class="form-control" id="editor2"></textarea>
                           </div>
                      </div>




                     <div class="row">
                            <div class="col-md-12">
                               <div class="form-group">
                                  <label class="bmd-label-floating" style="color:black;font-weight: 600">Mã Sản Phẩm</label>
                                  <input type="number" class="form-control">
                               </div>
                            </div>
                         </div>
                     <button type="submit" class="btn btn-primary pull-right">Thêm Sản Phẩm</button>
                     <div class="clearfix"></div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>