<?php /* C:\xampp\htdocs\piano_salem_laravel\resources\views/PageAdmin/sualoaisanpham.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-2"></div>
         <div class="col-md-8">
            <div class="card">
               <div class="card-header card-header-primary">
                  <h4 style="text-align:center;font-weight: 600" class="card-title">Sửa loại sản phẩm</h4>
               </div>
               <div class="card-body">
                    

                    
                   <p style="color:black;font-weight: 400"><?php echo e($loaisanpham->tenSP); ?></p>
                  <form action="" method="POST">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                     <br>
                     <div class="row">
                        <div class="col-md-4">
                        </div>
                        <div class="col-md-4">
                           <div class="form-group">
                              <label class="bmd-label-floating">Tên sản phẩm</label>
                              <input type="text" class="form-control" name="tenSP" value="<?php echo e($loaisanpham->tenSP); ?>">
                           </div>
                        </div>
                        <div class="col-md-4">
                        </div>
                     </div>
                     <button type="submit" class="btn btn-primary pull-right">Sửa loại sản phẩm</button>
                     <div class="clearfix"></div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>