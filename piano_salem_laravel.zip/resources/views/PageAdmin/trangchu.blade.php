@extends('Admin.master')

@section('noidung')
<br><br><br><br><br>

<h2 style="text-align:center;font-weight: 600;">Hello Admin mời chọn menu bên trái</h2>

@endsection
