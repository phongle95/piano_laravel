<?php /* C:\xampp\htdocs\piano_laravel1\resources\views/PageAdmin1/menu/danhsach.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>

<div class="row">
    <div class="col-md-12">
        <!-- DATA TABLE -->
        <h3 class="title-5 m-b-35">Danh Sách Menu</h3>
        <div class="table-data__tool">
            <div class="table-data__tool-left">
                    <?php if(session('thongbao')): ?>
                    <div style="color:green;font-weight: 400; text-align:center">
                        <?php echo e(session('thongbao')); ?>

                    </div>

                    <?php endif; ?>

                    <?php if(session('xoa')): ?>
                    <div style="color:red;font-weight: 400; text-align:center">
                        <?php echo e(session('xoa')); ?>

                    </div>

                    <?php endif; ?>
            </div>

        </div>
        <div class="table-responsive table-responsive-data2">
            <table class="table table-data2">
                <thead>
                    <tr>

                        <th>Tên Menu</th>
                        <th>Sửa</th>


                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="tr-shadow">

                        <td><?php echo e($mn->tenMenu); ?></td>

                        <td>
                            <a href="<?php echo e(route('PageAdmin1.menu.sua',$mn->id)); ?>" class="btn btn-outline-success btn-fw"> Sửa</a>

                        </td>

                    </tr>
                    <tr class="spacer"></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin2.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>