<?php /* C:\xampp\htdocs\piano_laravel1\resources\views/PageAdmin/menu/danhsach.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>
<br>

<h2 style="text-align:center;font-weight: 600;">Danh sách menu</h2>

<?php if(session('xoa')): ?>
<div style="color:red;font-weight: 400; text-align:center">
    <?php echo e(session('xoa')); ?>

</div>

<?php endif; ?>
<!-- End Navbar -->
<div class="content">
<div class="container-fluid">
<div class="row">
   <div class="col-md-12">
      <div class="card">
         <div class="card-header card-header-primary">
            <h3 style="text-align:center;font-weight: 600;">Danh sách menu</h3>
         </div>
         <div class="card-body">
            <div class="table-responsive">
               <table class="table">
                  <thead>
                     <th style="text-align:left;font-weight: 600;">
                        TÊN MENU
                     </th>

                     <th style="text-align:left;font-weight: 600;">
                        SỬA
                     </th>
                     
                  </thead>
                  
                  <tbody>
                      <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <tr>
                        <td style="text-align:left;font-weight: 500;">
                           <?php echo e($mn->tenMenu); ?>

                        </td>

                        <td style="text-align:left;font-weight: 500;">
                           <a href="<?php echo e(route('PageAdmin.menu.sua',$mn->id)); ?>" class="btn btn-primary btn-round">Sửa</a>
                        </td>
                        
                     </tr>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>