<?php /* C:\xampp\htdocs\piano_laravel1\resources\views/Layouts/sitemap.blade.php */ ?>
<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
        <url>
            <loc><?php echo e(route('Pages.trangchu')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <url>
            <loc><?php echo e(route('Pages.sanpham')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <url>
            <loc><?php echo e(route('Pages.gioithieu')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <url>
            <loc><?php echo e(route('Pages.suachua')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <url>
            <loc><?php echo e(route('Pages.tochucsukien')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <url>
            <loc><?php echo e(route('Pages.chothuenhaccu')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>
        <url>
            <loc><?php echo e(route('Pages.lienhe')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <url>
            <loc><?php echo e(route('Pages.giaoduc')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <url>
            <loc><?php echo e(route('Pages.timkiem')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>
        <url>
            <loc><?php echo e(route('Pages.video')); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>1</priority>
        </url>

        <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(route('Pages.chitiet',['slug' => str_slug($sp->tenSP),'id'=>$sp->id])); ?></loc>
            <lastmod><?php echo e(now()->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>daily</changefreq>
            <priority>0.8</priority>
        </url>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </urlset>
