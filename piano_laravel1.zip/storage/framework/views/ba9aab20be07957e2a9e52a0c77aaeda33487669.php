<?php /* C:\xampp\htdocs\piano_laravel1\resources\views/PageAdmin1/sanpham/them.blade.php */ ?>
<?php $__env->startSection('noidung'); ?>

<div class="row">

    <div class="col-md-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        <!-- DATA TABLE -->
            <div class="card">
                    <div class="card-header">
                        <strong>Thêm Sản Phẩm</strong>

                    </div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(route('PageAdmin1.sanpham.them')); ?>"  enctype="multipart/form-data" method="POST" class="form-horizontal">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">

                                                    <label class="badge badge-info">Tên Sản Phẩm</label><br><br>
                                                    <input type="text" id="text-input" name="tenSP" value="<?php echo e(old('tenSP')); ?>" placeholder="Nhập tên sản phẩm" class="form-control">
                                                </div>

                                    </div>

                                    <div class="row form-group">

                                        <div class="col-12 col-md-12">
                                                <label class="badge badge-info">Tên Title Meta</label><br>
                                                <input type="text" id="text-input" name="title" value="<?php echo e(old('title')); ?>" placeholder="Nhập tên title" class="form-control">
                                            </div>

                                    </div>

                                    <div class="row form-group">

                                        <div class="col-12 col-md-12">
                                                <label class="badge badge-info">Description Meta</label><br>
                                                <textarea  id="textarea-input" rows="5" placeholder="Nhập nội dung" class="form-control" name="description"><?php echo e(old('description')); ?></textarea>
                                            </div>

                                </div>

                                    <div class="row form-group">

                                        <div class="col-12 col-md-12">
                                                <label class="badge badge-info">Keyword Meta (SEO)</label><br>
                                                <input type="text" id="text-input" name="keyword" value="<?php echo e(old('keyword')); ?>" placeholder="Nhập Keyword" class="form-control">
                                            </div>

                                </div>

                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">

                                                    <label class="badge badge-info">Giá Sản Phẩm</label><br>
                                                    <input type="number" id="text-input" placeholder="Nhập giá sản phẩm" name="gia" value="<?php echo e(old('gia')); ?>" class="form-control">
                                                </div>

                                    </div>



                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Chọn Hình</label><br><br>
                                                    <input type="file" style="width:200px" name="img" value="<?php echo e(old('img')); ?>">

                                            </div>

                                    </div>

                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Tóm Tắt</label><br>
                                                    <textarea  id="textarea-input" rows="5" placeholder="Nhập nội dung" class="form-control" name="tomTat"><?php echo e(old('tomTat')); ?></textarea>
                                                </div>

                                    </div>

                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Mô Tả Sản Phẩm</label><br>
                                                    <textarea  id="editor1" rows="5" placeholder="Nhập nội dung" class="form-control" name="MTSP"><?php echo e(old('MTSP')); ?></textarea>
                                             </div>

                                    </div>
                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Thông Số Kĩ Thuật</label><br>
                                                    <textarea  id="editor2" rows="5" placeholder="Nhập nội dung" class="form-control" name="TSKT"><?php echo e(old('TSKT')); ?></textarea>
                                                </div>

                                    </div>

                                    <div class="row form-group">

                                            <div class="col-12 col-md-12">
                                                    <label class="badge badge-info">Mã Sản Phẩm</label><br>
                                                    <select name="maSP" class="form-control">
                                                            <?php $__currentLoopData = $loaisanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lsp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($lsp->maSP); ?>"><?php echo e($lsp->tenSP); ?></option>
                                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>

                                    </div>

                               <div class="card-footer">
                                    <button type="submit" class="btn btn-success btn-fw">
                                         Thêm
                                    </button>
                                    <a href="<?php echo e(route('PageAdmin1.sanpham.danhsach')); ?>" class="btn btn-info btn-fw">
                                        Quay về
                                    </a>
                                </div>
                        </form>
                    </div>

                </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin2.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>